package com.example.databaseRest.database;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class CreatePlayersAndTeams {

    /** Creates a new instance of CreatePlayersAndTeams */
    public CreatePlayersAndTeams() {
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Player extractedPlayerFormDataBase = null;
        // Create the EntityManager
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("league");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();

        for(Team team: teams) {
            em.persist(team);
        }

        for(Player player: players) {
            player.setTeam(teams[0]);
            teams[0].addPlayer(player);
            em.persist(player);
        }

        em.getTransaction().commit();

        //Find and Save a Player from the Database
        Player player = em.find(Player.class, 105L);
        if (player != null) {
            extractedPlayerFormDataBase = player;
        }

        em.close();
        emf.close();

        assert extractedPlayerFormDataBase != null;
        System.out.println(extractedPlayerFormDataBase.getFirstName() +" " +extractedPlayerFormDataBase.getLastName() +"!!!!!!!!!!!!!!!!!!!! It worked!");
    }

    private static Player[] players = new Player[] {
            // name, number, last quoted statement
            new Player("Lowe", "Derek", 23, "The sinker's been good to me."),
            new Player("Kent", "Jeff", 12, "I wish I could run faster."),
            new Player("Garciaparra", "Nomar", 5,
                    "No, I'm not superstitious at all.")

    };

    public static Team[] teams = new Team[] {
            new Team("Los Angeles Dodgers", "National"),
            new Team("San Francisco Giants", "National"),
            new Team("Anaheim Angels", "American"),
            new Team("Boston Red Sox", "American")
    };


}