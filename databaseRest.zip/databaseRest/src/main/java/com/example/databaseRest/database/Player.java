package com.example.databaseRest.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;
import java.io.Serializable;

@Entity (name="BaseballPlayer")
//@Table(name="BASEBALL_PLAYER")
public class Player implements Serializable {

    private Long    id;
    private String  lastName;
    private String  firstName;
    private int     jerseyNumber;
    private String  lastSpokenWords;
    private Team team;

    /** Creates a new instance of Player */
    public Player() {
    }

    public Player(String firstName, String lastName, int jerseyNumber, String lastSpokenWords) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.jerseyNumber = jerseyNumber;
        this.lastSpokenWords = lastSpokenWords;
    }

    /**
     * Gets the id of this Player. The persistence provider should
     * autogenerate a unique id for new player objects.
     * @return the id
     */
    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public int getJerseyNumber() {
        return jerseyNumber;
    }

    public void setJerseyNumber(int jerseyNumber) {
        this.jerseyNumber = jerseyNumber;
    }

    @Transient
    public String getLastSpokenWords() {
        return lastSpokenWords;
    }

    public void setLastSpokenWords(String lastSpokenWords) {
        this.lastSpokenWords = lastSpokenWords;
    }

    @ManyToOne
    public Team getTeam() {
        return team;
    }

    public void setTeam(Team team) {
        this.team = team;
    }
}
