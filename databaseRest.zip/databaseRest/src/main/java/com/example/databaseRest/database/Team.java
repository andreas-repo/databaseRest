package com.example.databaseRest.database;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;

@Entity
public class Team implements Serializable {

    private Long id;
    private String teamName;
    private String division;
    private Collection<Player> players;


    private Team team;

    public Team(String teamName, String division) {
        this.teamName = teamName;
        this.division = division;
        this.players = new HashSet<>();
    }

    @ManyToOne
    public Team getTeam() {
        return team;
    }


    /** Creates a new instance of Team */
    public Team() {
        players = new HashSet();
    }


    /**
     * Gets the id of this Team.
     * @return the id
     */
    @Id
    @GeneratedValue
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTeamName() {
        return teamName;
    }

    public void setTeamName(String teamName) {
        this.teamName = teamName;
    }

    public String getDivision() {
        return division;
    }

    public void setDivision(String division) {
        this.division = division;
    }


    @OneToMany(mappedBy = "team")
    public Collection<Player> getPlayers() {
        return players;
    }

    public void setPlayers(Collection<Player> players) {
        this.players = players;
    }

    public void setTeam(Team team) {
        this.team = team;
    }

    public void addPlayer(Player player) {
        this.players.add(player);
    }
}
